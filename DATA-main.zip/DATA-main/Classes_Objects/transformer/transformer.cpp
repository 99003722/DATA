#include "transformer.h"

transformer::transformer(/* args */):primary_turns(100), secondary_turns(100), ip_voltage(240), op_voltage(240)
{
    get_primary_turn(); //??
 /*
    Assigning and not initialization
    primary_tunrs = 100;
    secondary_turn = 100;
    ip_voltage = 240;
    op_voltage = 240;
    */
}

unsigned int transformer::get_primary_turn()
{
    return primary_turns;
}

unsigned int transformer::get_secondary_turn()
{
    return secondary_turns;
}

transformer::~transformer()
{
}