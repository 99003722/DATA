/**
 * @file tranformer.h
 * @author Bharath.G (bharath.g@ltts.com)
 * @brief 
 * @version 0.1
 * @date 2021-04-08
 * 
 * @copyright Copyright (c) 2021
 * 
 */
/*
    Tranformer object
        Data
            primary_tunrs
            secondary_turn
            ip_voltage
            op_voltage
        Operations
            stepup
            stepdown
            get_primary_turn
            get_secondary_turn
            efficinecy
*/  

#ifndef __TRANSFORMER_H_
#define __TRANSFORMER_H_

class transformer
{
private: // protected
    /* data */
    unsigned int primary_turns;
    unsigned int secondary_turns;
    float ip_voltage;
    float op_voltage;
public:
    transformer();
   // void stepup(void);
    //void stepdown();
    unsigned int get_primary_turn(void);
    unsigned int get_secondary_turn(void);
    //float efficinecy();
    ~transformer();
};


#endif