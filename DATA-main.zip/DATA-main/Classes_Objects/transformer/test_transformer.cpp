#include "transformer.h"
#include <gtest/gtest.h>
TEST(transformer,DefaultConstructor) {
    transformer T1;
    EXPECT_EQ(100,T1.get_primary_turn());
    EXPECT_EQ(100,T1.get_secondary_turn());
}

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}