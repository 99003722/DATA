fraction<P>fraction<P>::operator*(fraction<P>&obj)
// {
//     fraction<P> c3;
//     P lcm;
//     P numer;
//     lcm=numernator*obj.numernator;    
//     numer=;   
//     P common_factor = gcd(numer,lcm);
//     c3.numernator = lcm / common_factor;
//     c3.numerator = numer / common_factor; 
//     return c3;
// };