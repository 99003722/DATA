/**
 * @file Mstring.h
 * @author Bharath.G (bharath.g@ltts.com)
 * @brief 
 * @version 0.1
 * @date 2021-04-09
 * 
 * @copyright Copyright (c) 2021
 * 
 */
#ifndef __MYSTRING_H_
#define __MYSTRING_H_
#include <stdlib.h>

class Mstring
{
private:
    char* str;
    size_t len;

public:
    Mstring(/* args */);
    Mstring(const char* );
    Mstring(const Mstring& );
    void operator=(char*);
    ~Mstring();
};

#endif //__MYSTRING_H