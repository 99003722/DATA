#include "Mstring.h"
#include "string.h"

void Mstring::operator=(char* tstr)
{
    len = strlen(tstr);
    str = new char[ len + 1 ];
    strncpy(str, tstr, len+1);
}