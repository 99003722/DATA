#include "polygon.h"

polygon::polygon(int n1,int n2):m_side1(n1),m_side2(n2)
{}