# Errors
#### error 1- while testing display function - undefined reference to the dipslay function and constructor which is getting called
#### error 2- while testing for constructor(
#### doubt - while testing for constructor class members where made public..how to test in private mode or it should be always public during testing
