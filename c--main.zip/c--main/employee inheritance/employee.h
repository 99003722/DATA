#include<iostream>
using namespace std;
class IEmployee{
public:
virtual void payroll()=0;
virtual void appraisal()=0;
};
