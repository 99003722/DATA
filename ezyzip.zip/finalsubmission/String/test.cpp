#include "strings.h"
#include <gtest/gtest.h>
TEST(ctr1,Mstring) {
Mstring s1("atamm");
EXPECT_EQ(PASS,s1.stringcheck("atamm"));
}

TEST(add,Mstring) 
{
Mstring s4("atamm");
Mstring s5="atamm";
Mstring s6=s4+s5;
EXPECT_EQ(PASS,s6.stringcheck("atammatamm"));
s5.update("hi");
EXPECT_EQ(PASS,s5.stringcheck("hi"));
EXPECT_EQ(PASS,s6.stringcheck("atammatamm"));

}

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}