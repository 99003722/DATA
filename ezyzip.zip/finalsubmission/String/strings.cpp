#include "strings.h"
Mstring::Mstring():array(0)
{}
Mstring::Mstring(const char* string_user)
{
    int len=strlen(string_user);
    length=len;
    array=new char[len+1];
    for(int i=0;i<len+1;i++)
    {
      array[i]=string_user[i];
    }
}
Mstring::Mstring(const Mstring &obj)
{
    length=obj.length; 
    array=new char[length+1];
    strcpy(array,obj.array);
}
Mstring::~Mstring()
{
    delete[] array;
}
Mstring Mstring::operator=(const char *new_string)
{
    int len1=strlen(new_string);
    delete[] array;
    length=len1+1;
    array=new char[length];
    strcpy(array,new_string);
    
}
Mstring Mstring::operator=(const Mstring &obj)
{
    Mstring result;
    result.array=obj.array;
    result.length=obj.length;
}
bool Mstring::operator==(const Mstring &obj)
{
    if(strcmp(array,obj.array)==0)
    {
      return true;
    }
      return false;
}
Mstring Mstring::operator+(const Mstring &obj)
{
    Mstring result;
    int len2=length+obj.length;
    result.length=len2-1;
    result.array= new char[len2-1];
    for(int i=0;i<len2;i++)
    {
      if(i<length)
      {
        //cout<<array[i];
      result.array[i]=array[i];

      }
      else
      {        
        result.array[i]=obj.array[i-(obj.length)];
      }
      
    }
    return result;
}

void Mstring::display()
{
  for(int i=0;i<=length;i++)
  {
    cout<<array[i];
  }
}
enum_t Mstring::stringcheck(const char *check_char)
{
  if(strcmp(array,check_char)!=0)
  {
    return FAIL;
  }
  else
  {
    return PASS;
  }

}
enum_t Mstring::update(const char *new_string)
{
int lnt=strlen(new_string);
delete[] array;;
length=lnt+1;
array=new char(lnt+1);
strcpy(array,new_string);
}