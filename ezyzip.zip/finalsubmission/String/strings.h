#ifndef STRINGS_H
#define STRINGS_H
#include<string.h>
#include<iostream>
using namespace std;
typedef enum
{
    PASS,
    FAIL
}enum_t;
class Mstring
{
private:
    char* array;
    size_t length;
public:
    Mstring(); 
    Mstring(const char*); 
    Mstring(const Mstring &obj);
    ~Mstring();
    Mstring operator=(const char *new_string);
    Mstring operator=(const Mstring &obj);
    bool operator==(const Mstring &obj);
    Mstring operator+(const Mstring &obj);
    void display();
    enum_t stringcheck(const char *check_char);
    enum_t update(const char *new_string);
};
#endif
