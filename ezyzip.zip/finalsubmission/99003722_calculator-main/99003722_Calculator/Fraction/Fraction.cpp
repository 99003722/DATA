#include "Fraction.h"
#include <iostream>
using namespace std;
template<typename P>
fraction<P>::fraction()
{
    numerator=0;
    denominator=0;
};
template<typename P>
fraction<P>::fraction(P x,P y):numerator(x),denominator(y)
{};
template<typename P>
P fraction<P>::gcd(P x,P y)
{
    if (x == 0)
        return y;
    return gcd(y % x, x);
}
template<typename P>
fraction<P>fraction<P>::operator+(fraction<P>&obj)
{
    fraction<P> c3;
    P lcm;
    P nume;
    lcm=denominator*obj.denominator;    
    nume=(lcm/denominator)*numerator+(lcm/obj.denominator)*obj.numerator;   
    
    P common_factor = gcd(nume,lcm);
    c3.denominator = lcm / common_factor;
    c3.numerator = nume / common_factor; 
    return c3;
};
template<typename P>
fraction<P>fraction<P>::operator-(fraction<P>&obj)
{
    fraction<P> c3;
    P lcm;
    P nume;
    lcm=denominator*obj.denominator;    
    nume=(lcm/denominator)*numerator-(lcm/obj.denominator)*obj.numerator;   
    P common_factor = gcd(nume,lcm);
    c3.denominator = lcm / common_factor;
    c3.numerator = nume / common_factor; 
    return c3;
};
template<typename P>
fraction<P>fraction<P>::operator*(fraction<P>&obj)
{
    fraction<P> c3;
    P lcm;
    P nume;
    lcm=denominator*obj.denominator;    
    nume=numerator*obj.numerator;   
    P common_factor = gcd(nume,lcm);
    c3.denominator = lcm / common_factor;
    c3.numerator = nume / common_factor; 
    return c3;
};
template<typename P>
fraction<P>fraction<P>::operator/(fraction<P>&obj)
{
    fraction<P> c3;
    P lcm;
    P nume;
    lcm=denominator*obj.numerator;    
    nume=numerator*obj.denominator;
    P common_factor = gcd(nume,lcm);
    c3.denominator = lcm / common_factor;
    c3.numerator = nume / common_factor; 
    return c3;
};



template<typename P>
void fraction<P>::display()
{
    cout<<"Numerator="<<numerator<<endl;
    cout<<"denominator="<<denominator<<endl;
};

template<typename P>
P fraction<P>::return_denominator_value()
{
   return denominator;
};
template<typename P>
P fraction<P>::return_numerator_value()
{
   return numerator;
};
