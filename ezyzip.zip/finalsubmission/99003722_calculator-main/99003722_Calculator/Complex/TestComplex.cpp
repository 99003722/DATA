#include "Complex.h"
#include <gtest/gtest.h>
TEST(complex,DefaultConstructor) 
{
    complex<int> com1(1,2),com2(3,3),comtest;
    comtest=com1+com2;
    EXPECT_EQ(4,comtest.return_real_value());
    EXPECT_EQ(5,comtest.return_imaginary_value());
    comtest=com1-com2;
    EXPECT_EQ(-2,comtest.return_real_value());
    EXPECT_EQ(-1,comtest.return_imaginary_value());
}

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}