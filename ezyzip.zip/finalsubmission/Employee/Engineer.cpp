#include"Engineer.h"
Engineer::Engineer(std::string id,std::string name,double salary,int exp,int code):Employee(id,name,salary,exp)
{
m_projcode=code;
}
void Engineer::payroll()
{
m_salary+=5000;
}
void Engineer::appraisal()
{
m_salary+=5000;
}
void Engineer::display()
{
cout<<"id"<<m_empid;
}
int Engineer::code()
{
return m_projcode;
}
