#include"Employee.h"
class Manager:public Employee
{
int m_projcode;
int m_reportees;
public:
Manager(std::string id,std::string name,double salary,int exp,int code,int n);
void payroll();
void appraisal();
void display();
int code();
int report();
};

