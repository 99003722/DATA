#include"Manager.h"
Manager::Manager(std::string id,std::string name,double salary,int exp,int code,int n):Employee(id,name,salary,exp)
{
m_projcode=code;
m_reportees=n;
}
void Manager::payroll()
{
m_salary+=1000;
}
void Manager::appraisal()
{
m_salary+=1000;
}
void Manager::display()
{
cout<<"id"<<m_empid;
}
int Manager::code()
{
return m_projcode;
}
int Manager::report()
{
return m_reportees;
}

