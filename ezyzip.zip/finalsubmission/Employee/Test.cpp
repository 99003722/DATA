#include "Manager.h"
#include <gtest/gtest.h>
TEST(ctr,manage) {
Manager m("1","name",1000,3,2,1);
EXPECT_EQ(2,m.code());
EXPECT_EQ(1,m.report());

EXPECT_EQ("1",m.id());
EXPECT_EQ("name",m.name());
EXPECT_EQ(1000,m.salary());
EXPECT_EQ(3,m.exp());
}
TEST(appraisal,manage) {
Manager m1("1","name",1000,3,2,1);
m1.appraisal();
EXPECT_EQ(2000,m1.salary());
m1.payroll();
EXPECT_EQ(3000,m1.salary());
}
int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
