#include"IEmployee.h"
class Employee:public IEmployee
{
protected:
std::string  m_empid;
std::string m_name;
int m_salary;
int m_exp;
public:
Employee(std::string id,std::string name,int salary,int exp);
virtual void display();
std::string id();
std::string name();
int salary();
int exp();
};