#include"Employee.h"
using namespace std;
Employee::Employee(std::string id,std::string name,int salary,int exp):m_empid(id),m_name(name),m_salary(salary),m_exp(exp)
{
};
void Employee::display()
{
cout<<"id"<<m_empid<<endl;
}
std::string Employee::id()
{
return m_empid;
}
std::string Employee::name()
{
return m_name;
}
int Employee::salary()
{
return m_salary;
}
int Employee::exp()
{
return m_exp;
}