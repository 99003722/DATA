#include "stdint.h"
#include "string.h"
#include <iostream>
class Mystring
{
private:
    /* data */
    uint8_t len;
    char* array;

public:
    Mystring();
    Mystring(const char*);
    Mystring(const Mystring&);
    ~Mystring();

    Mystring& operator=(const Mystring&);
    void display();

};

Mystring::Mystring(/* args */):
    len(0),array(nullptr)
{
}

Mystring::Mystring(const char* ptr):
    len(strlen(ptr)),array(nullptr)
{
    array = new char[len];
    strncpy(array, ptr, len);
}

Mystring::Mystring(const Mystring& ref):
    len(ref.len),array(nullptr)
{
    array = new char[len];
    strncpy(array, ref.array, len);
}

Mystring& Mystring::operator=(const Mystring& ref)
{
    this->len = ref.len;
    strncpy(this->array, ref.array, this->len);

    return *this;
}

Mystring::~Mystring()
{
    if(nullptr != array)
        delete[] array;
}

void Mystring::display()
{
    std::cout << array <<std::endl;
}
int main()
{
    Mystring S1();
    Mystring S2("Hello");
    Mystring S3(S2);
    Mystring S4 = S2;
    S3.display();
    return 0;
}