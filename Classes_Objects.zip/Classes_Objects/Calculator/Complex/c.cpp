#include"c.h"
#include<iostream>
template<typename T>
Complex<T>::Complex():re(0), img(0)
{}
template <typename T>
Complex<T>::Complex(const T op1,const T op2):re(op1), img(op2)
{}
template <typename T>
Complex<T> Complex<T>::operator + (Complex<T>& obj)
{
    Complex<T> local_var;
    local_var.re = re+obj.re;
    local_var.img = img+obj.img;
    return local_var;
}
template <typename T>
Complex<T> Complex<T>::operator - (Complex<T>& obj)
{
    Complex<T> local_var;
    local_var.re = re-obj.re;
    local_var.img = img-obj.img;
    return local_var;
}
template <typename T>
Complex<T> Complex<T>::operator / (Complex<T>& obj)
{
    Complex<T> local_var;
    local_var.re = re/obj.re;
    local_var.img = img/obj.img;
    return local_var;
}
template <typename T>
Complex<T> Complex<T>::operator * (Complex<T>& obj)
{
    Complex<T> local_var;
    local_var.re = re*obj.re;
    local_var.img = img*obj.img;
    return local_var;
}
template <typename T>
void Complex<T>::print()
{
    cout<<re<<"+ i"<<img;

}
int main()
{
    Complex<int>c1(10.000,20.00);
    Complex<int>c2(1.00,20.000);
    Complex<int>c3=c1/c2;
    c3.print();
}


