#ifndef __FRACTION_H_
#define __FRACTION_H_
class fraction
{
    
}
#endif

