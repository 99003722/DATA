#include<iostream>
#include<stdlib.h>
using namespace std;
#ifndef __COMPLEX_H_
#define __COMPLEX_H_
template <class T>
class Complex
{
    T re;
    T img;
    public:
        Complex();
        Complex(const T,const T);
        void print();
        Complex operator + (Complex&);
        Complex operator - (Complex&);
        Complex operator / (Complex&);
        Complex operator * (Complex&);
        
        
    
};

#endif